`timescale 1ns / 1ps

module Top(
    input clk,

    input [3:0] BTN,
    input BTNX4,
    input [15:0] SW,
    input ps2_clk,
    input ps2_data,

    output [7:0] LED,
    output [7:0] SEGMENT,
    output [3:0] AN,

    output [3:0] r,
    output [3:0] g,
    output [3:0] b,
    output hs,
    output vs,
    output rstn,

    output LED_CLK,
    output LED_CLR,
    output LED_DT,
    output LED_EN,

    output SEG_CLK,
    output SEG_CLR,
    output SEG_DT,
    output SEG_EN
);

assign rstn = 1'b1;

// =======================
// 100MHz -> 25MHz VGA clock
// 参照 rhythm-game 工程：VGA_Driver 使用 25MHz vga_clk
// =======================
reg [1:0] clk_div = 2'b00;
always @(posedge clk) begin
    clk_div <= clk_div + 1'b1;
end
wire clk_VGA = clk_div[1];

// =======================
// 原跳舞机游戏部分
// =======================
wire [3:0] BTN_DB;
wire [7:0] score;
wire [1:0] error_cnt;
wire [3:0] level;
wire game_over;

debounce D0(
    .clk(clk),
    .key_in(BTN[0]),
    .key_out(BTN_DB[0])
);

debounce D1(
    .clk(clk),
    .key_in(BTN[1]),
    .key_out(BTN_DB[1])
);

debounce D2(
    .clk(clk),
    .key_in(BTN[2]),
    .key_out(BTN_DB[2])
);

debounce D3(
    .clk(clk),
    .key_in(BTN[3]),
    .key_out(BTN_DB[3])
);

game_core U_GAME(
    .clk(clk),
    .BTN(BTN_DB),
    .LED(LED),
    .score(score),
    .error_cnt(error_cnt),
    .level(level),
    .game_over(game_over)
);

seg_driver U_SEG(
    .clk(clk),
    .score(score),
    .error_cnt(error_cnt),
    .level(level),
    .game_over(game_over),
    .SEGMENT(SEGMENT),
    .AN(AN)
);

// =======================
// VGA显示部分
// =======================
wire [11:0] rgb_real;
wire [8:0] y;
wire [9:0] x;
wire read_en_n;

vga_game_display U_VGA_DISPLAY(
    .x(x),
    .y(y),
    .read_en_n(read_en_n),
    .target_led(LED[3:0]),
    .score(score),
    .error_cnt(error_cnt),
    .level(level),
    .game_over(game_over),
    .rgb_real(rgb_real)
);

VGA_Driver U_VGA_DRIVER(
    .d_in(rgb_real),
    .vga_clk(~clk_VGA),
    .clrn(1'b1),
    .row_addr(y),
    .col_addr(x),
    .r(r),
    .g(g),
    .b(b),
    .rdn(read_en_n),
    .hs(hs),
    .vs(vs)
);

// =======================
// 不使用的串行LED/串行七段码接口，固定为安全状态
// =======================
assign LED_CLK = 1'b0;
assign LED_CLR = 1'b1;
assign LED_DT  = 1'b0;
assign LED_EN  = 1'b0;

assign SEG_CLK = 1'b0;
assign SEG_CLR = 1'b1;
assign SEG_DT  = 1'b0;
assign SEG_EN  = 1'b0;

endmodule
